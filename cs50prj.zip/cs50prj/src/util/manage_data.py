from resource.facilities import facilities, facilities2
from com.cs50.server.db_util import get_data_by_state
from com.cs50.server.db_manager import get_data_for_all


def retrieve_all():
    #return facilities
    a = get_data_for_all()
    return a


def retrieve_by_state(state):
    x = get_data_by_state(state)
    return x


def retrieve_by_state2(state):
    print(facilities2[state])
    return facilities2[state]


def retrieve_by_city(state, city):
    for c in facilities[state]:
        if c.get("city") == city:
            return c


#print(retrieve_all())
#retrieve_by_state("CA")
#print(retrieve_by_city("NV", "Reno"))
