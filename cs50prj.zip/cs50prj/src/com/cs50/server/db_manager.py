from com.cs50.server.db_util import get_data_by_state,insert_record,get_data_for_all


def retrieve_by_state(state):
    return list(get_data_by_state(state))


def retrieve_by_all():
    return list(get_data_for_all())


def insert(facility, city, county, state, total_patients, recovered):
    if facility is not None and city is not None and county is not None:
        insert_record(facility, city, county, state, total_patients, recovered)
        return True
    else:
        return False


#print(retrieve_by_state("CA"))
#print(retrieve_by_all())

#insert_record('Elko Hospital', 'Elko','Elko', 'NV', 500,450)