import flask
from flask import request, make_response
from util.manage_data import retrieve_by_state, retrieve_by_city
from com.cs50.server.db_manager import retrieve_by_state, insert, retrieve_by_all
from flask import jsonify
from flask_cors import CORS

app = flask.Flask(__name__)
app.config["DEBUG"] = True
CORS(app)


@app.route('/', methods=['GET'])
def home():
    return "<h1>COVID Surge</h1><p>This site is to provide the COVID virus affected people data around the Country.</p>"


@app.route('/api/v1/resources/facilities/all', methods=['GET'])
def api_all():
    try:
        return jsonify(retrieve_by_all())
    except Exception as e:
        print(e)


@app.route('/api/v1/resources/facilities/<state>', methods=['GET'])
def api_state(state):
    try:
        return jsonify(retrieve_by_state(state))
    except Exception as e:
        print(e)


@app.route('/api/v1/resources/facilities/<state>/<city>', methods=['GET'])
def api_state_city(state, city):
    try:
        return jsonify(retrieve_by_city(state, city))
    except Exception as e:
        print(e)


@app.route('/api/v1/resources/facilities/add', methods=['POST'])
def api_add_record():
    try:
        print(request.method)
        request_data = request.get_json(force=True)
        print(request_data)
        facility = request_data['facility']
        print(facility)
        city = request_data['city']
        county = request_data['county']
        state = request_data['state']
        total_patients = int(request_data['totalPatients'])
        recovered = int(request_data['recovered'])
        insert(facility,city,county,state,total_patients,recovered)
        response = make_response(
            jsonify(
                {"message": str("SUCCESS"), "severity": "none"}
            ),
            201,
        )
        response.headers["Content-Type"] = "application/json"
        return response
    except Exception as e:
        print(e)
        response = make_response(
            jsonify(
                {"message": str("NOT_SUCCESSFUL"), "severity": "danger"}
            ),
            500,
        )
        response.headers["Content-Type"] = "application/json"
        return response


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8080, debug=True)
