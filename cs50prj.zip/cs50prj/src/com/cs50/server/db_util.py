import sqlite3


def create_table():
    conn = sqlite3.connect("covid_db")
    cursor = conn.cursor()
    cursor.execute(''' DROP TABLE IF EXISTS facility_patients ''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS facility_patients
               (facility text, city text, county text, state text, total_patients int, recovered int,  
               PRIMARY KEY (facility, city, county))''')
    conn.close()


def insert_record(facility, city, county, state, total_patients, recovered):
    try:
        print(facility)
        conn = sqlite3.connect("covid_db")
        cursor = conn.cursor()
        cursor.execute("INSERT INTO facility_patients VALUES(?,?,?,?,?,?)",
                       (facility, city, county, state, total_patients, recovered))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(e)
        return False


def delete_data():
    conn = sqlite3.connect("covid_db")
    cursor = conn.cursor()
    cursor.execute("DELETE FROM facility_patients WHERE city='Jersey'")
    conn.commit()
    conn.close()


def get_data_by_state(state):
    try:
        conn = sqlite3.connect("covid_db")
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM facility_patients WHERE state=:state ", {"state": state})
        p = map(list, cursor.fetchall())
        conn.close()
        return p  # patients
    except Exception as e:
        print(e)


def get_data_for_all():
    try:
        conn = sqlite3.connect("covid_db")
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM facility_patients")
        pts = map(list, cursor.fetchall())
        conn.close()
        return pts
    except Exception as e:
        print(e)


# create_table()
#delete_data()
# insert_record('PAMF', 'Mountain View', 'Santa Clara', 'CA', 1000, 800)
# insert_record('EL Camino Hospital', 'Mountain View', 'Santa Clara', 'CA', 1000, 900)
# insert_record('Reno Hospital', 'Reno', 'Washoe', 'NV', 1000, 900)

#print(get_data_by_state('NV'))
#print(list(get_data_for_all()))
