facilities = {
    "CA": [
            {"facilityName": "EL Camino Hospital", "city": "Mountain View", "patients": 1000, "recovered": 800, "dead": 200},
            {"facilityName": "Kaiser", "city": "Santa Clara", "patients": 1200, "recovered": 900, "dead": 300},
            {"facilityName": "PAMF", "city": "Sunnyvale", "patients": 800, "recovered": 600, "dead": 200}
          ],
    "NV": [
            {"facilityName": "Reno Hospital", "city": "Reno", "patients": 1000, "recovered": 800, "dead": 200},
            {"facilityName": "Carson Hospital", "city": "Carson", "patients": 1200, "recovered": 900, "dead": 300},
            {"facilityName": "ELk Grove Hospital", "city": "Elk Grove", "patients": 800, "recovered": 600, "dead": 200}
          ]

}
facilities2 = {
    "CA": [
            ["EL Camino Hospital", "Mountain View", "Santa Clara", "CA", 1000, 800, 200],
            ["Kaiser", "Fremont", "Alameda", "CA", 1200, 900, 300],
            ["PAMF", "Sunnyvale",  "Santa Clara", "CA", 800, 600,  200],
            ["General Hospital", "San Jose",  "Santa Clara", "CA", 1800, 1400,  400]
          ],
    "NV": [
            ["Reno Hospital", "Reno", "Washoe", "NV", 1000, 800, 200],
            ["Carson Hospital", "Carson City", "Ormsby", "NV", 1200,  900, 300],
            ["General Hospital", "Los Vegas",  "Clark", "NV", 800,  600, 200]
          ]

}
